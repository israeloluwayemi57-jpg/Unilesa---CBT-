use client";

import { useEffect, useMemo, useState } from "react";

const DEFAULT_COURSES = [
  {
    code: "BUA 101",
    title: "Introduction to Business",
    level: "100",
    department: "Business Administration",
    duration: 20,
    questions: [
      { id: "bua101-1", q: "Which of the following best describes business?", options: ["Production and exchange of goods and services", "Only buying imported goods", "Only government activities", "A type of examination"], answer: 0 },
      { id: "bua101-2", q: "Which function involves setting goals and deciding how to achieve them?", options: ["Planning", "Sleeping", "Advertising only", "Recruitment only"], answer: 0 },
      { id: "bua101-3", q: "An entrepreneur is primarily associated with:", options: ["Taking calculated business risks", "Avoiding every decision", "Only working for government", "Never introducing ideas"], answer: 0 },
      { id: "bua101-4", q: "Which is a factor of production?", options: ["Land", "Exam hall", "Certificate", "Timetable"], answer: 0 },
      { id: "bua101-5", q: "The main aim of most profit-oriented businesses is to:", options: ["Earn profit while satisfying customers", "Avoid customers", "Stop production", "Eliminate competition by force"], answer: 0 }
    ]
  },
  {
    code: "ACC 101",
    title: "Principles of Financial Accounting",
    level: "100",
    department: "Business Administration",
    duration: 20,
    questions: [
      { id: "acc101-1", q: "The basic accounting equation is:", options: ["Assets = Capital + Liabilities", "Assets = Sales - Expenses", "Capital = Sales + Purchases", "Liabilities = Assets + Expenses"], answer: 0 },
      { id: "acc101-2", q: "Which document records a business transaction?", options: ["Source document", "Novel", "Timetable", "Attendance sheet"], answer: 0 },
      { id: "acc101-3", q: "A trial balance is prepared mainly to:", options: ["Check the arithmetical accuracy of ledger entries", "Calculate students' attendance", "Set examination questions", "Advertise a business"], answer: 0 },
      { id: "acc101-4", q: "Cash introduced by the owner is treated as:", options: ["Capital", "Expense", "Loss", "Drawing"], answer: 0 },
      { id: "acc101-5", q: "A bank reconciliation statement compares:", options: ["Cash book and bank statement", "Sales and purchases", "Capital and drawings", "Assets and stock only"], answer: 0 }
    ]
  },
  {
    code: "ECO 101",
    title: "Principles of Economics",
    level: "100",
    department: "Business Administration",
    duration: 20,
    questions: [
      { id: "eco101-1", q: "Economics is mainly concerned with:", options: ["Scarce resources and unlimited wants", "Only money", "Only agriculture", "Only government"], answer: 0 },
      { id: "eco101-2", q: "The law of demand generally states that, other things equal:", options: ["Quantity demanded falls as price rises", "Demand always rises with price", "Price has no effect on demand", "Supply becomes zero"], answer: 0 },
      { id: "eco101-3", q: "Opportunity cost is the:", options: ["Next best alternative forgone", "Total money in a bank", "Cost of a building only", "Amount of tax paid"], answer: 0 },
      { id: "eco101-4", q: "A market is a place or arrangement where:", options: ["Buyers and sellers interact", "Only sellers meet", "Only governments meet", "No exchange occurs"], answer: 0 },
      { id: "eco101-5", q: "Inflation refers to a sustained increase in:", options: ["General price level", "School attendance", "Population only", "Exports only"], answer: 0 }
    ]
  },
  {
    code: "GST 111",
    title: "Use of English / General Studies",
    level: "100",
    department: "General Studies",
    duration: 15,
    questions: [
      { id: "gst111-1", q: "Choose the correctly spelt word.", options: ["Accommodation", "Accomodation", "Acommodation", "Accommmodation"], answer: 0 },
      { id: "gst111-2", q: "A synonym is a word that has:", options: ["A similar meaning", "An opposite meaning", "No meaning", "Only a plural form"], answer: 0 },
      { id: "gst111-3", q: "Which is a noun?", options: ["University", "Quickly", "Beautiful", "Run"], answer: 0 },
      { id: "gst111-4", q: "The opposite of 'ancient' is:", options: ["Modern", "Old", "Historic", "Former"], answer: 0 },
      { id: "gst111-5", q: "A sentence that asks a question is:", options: ["Interrogative", "Declarative", "Imperative", "Exclamatory"], answer: 0 }
    ]
  }
];

const EXTRA_CODES = ["BUA 191","BUA 193","AMS 101","AMS 103","POL 193","LIS 197","CSC 197","FAD 191","EDT 101","EDT 103","EDT 195"];

function shuffle(arr) {
  return [...arr].sort(() => Math.random() - 0.5);
}

export default function CBTApp() {
  const [courses, setCourses] = useState(DEFAULT_COURSES);
  const [screen, setScreen] = useState("home");
  const [student, setStudent] = useState({ name: "", matric: "", level: "100", department: "Business Administration" });
  const [selected, setSelected] = useState(null);
  const [examQuestions, setExamQuestions] = useState([]);
  const [answers, setAnswers] = useState({});
  const [current, setCurrent] = useState(0);
  const [seconds, setSeconds] = useState(0);
  const [result, setResult] = useState(null);
  const [adminUnlocked, setAdminUnlocked] = useState(false);
  const [adminPassword, setAdminPassword] = useState("");
  const [newCourse, setNewCourse] = useState({ code:"", title:"", department:"Business Administration", level:"100", duration:20 });
  const [newQuestion, setNewQuestion] = useState({ q:"", a:"", b:"", c:"", d:"", answer:"0" });

  useEffect(() => {
    try {
      const saved = localStorage.getItem("unilesa-cbt-courses");
      if (saved) setCourses(JSON.parse(saved));
    } catch {}
  }, []);

  useEffect(() => {
    localStorage.setItem("unilesa-cbt-courses", JSON.stringify(courses));
  }, [courses]);

  useEffect(() => {
    if (screen !== "exam" || seconds <= 0) return;
    const t = setInterval(() => setSeconds(s => s - 1), 1000);
    return () => clearInterval(t);
  }, [screen, seconds]);

  useEffect(() => {
    if (screen === "exam" && seconds === 0) finishExam();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [seconds, screen]);

  const filteredCourses = useMemo(
    () => courses.filter(c => c.level === student.level && c.department === student.department),
    [courses, student.level, student.department]
  );

  function startExam(course) {
    if (!student.name.trim()) return alert("Enter your full name first.");
    const qs = shuffle(course.questions).slice(0, Math.min(50, course.questions.length));
    if (!qs.length) return alert("This course has no questions yet.");
    setSelected(course);
    setExamQuestions(qs);
    setAnswers({});
    setCurrent(0);
    setResult(null);
    setSeconds(course.duration * 60);
    setScreen("exam");
  }

  function finishExam() {
    if (!examQuestions.length) return;
    const correct = examQuestions.reduce((n, q, i) => n + (answers[q.id] === q.answer ? 1 : 0), 0);
    const total = examQuestions.length;
    const percentage = Math.round((correct / total) * 100);
    setResult({ correct, total, percentage });
    setScreen("result");
  }

  function formatTime(s) {
    const m = Math.floor(s / 60).toString().padStart(2, "0");
    const sec = (s % 60).toString().padStart(2, "0");
    return `${m}:${sec}`;
  }

  function addCourse(e) {
    e.preventDefault();
    if (!newCourse.code || !newCourse.title) return;
    if (courses.some(c => c.code.toLowerCase() === newCourse.code.toLowerCase())) return alert("Course already exists.");
    setCourses([...courses, { ...newCourse, questions: [] }]);
    setNewCourse({ code:"", title:"", department:"Business Administration", level:"100", duration:20 });
  }

  function addQuestion(e) {
    e.preventDefault();
    if (!selected || !newQuestion.q || !newQuestion.a || !newQuestion.b || !newQuestion.c || !newQuestion.d) return;
    const q = {
      id: `${selected.code}-${Date.now()}`,
      q: newQuestion.q,
      options: [newQuestion.a,newQuestion.b,newQuestion.c,newQuestion.d],
      answer: Number(newQuestion.answer)
    };
    setCourses(cs => cs.map(c => c.code === selected.code ? { ...c, questions:[...c.questions,q] } : c));
    setSelected(c => c ? ({...c, questions:[...c.questions,q]}) : c);
    setNewQuestion({ q:"", a:"", b:"", c:"", d:"", answer:"0" });
  }

  function exportData() {
    const blob = new Blob([JSON.stringify(courses, null, 2)], {type:"application/json"});
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "unilesa-cbt-question-bank.json"; a.click();
    URL.revokeObjectURL(url);
  }

  if (screen === "exam") {
    const q = examQuestions[current];
    return (
      <main className="app">
        <header className="topbar"><div><b>UNILESA CBT</b><small>{selected.code} • {selected.title}</small></div><div className="timer">⏱ {formatTime(seconds)}</div></header>
        <section className="exam-card">
          <div className="progress"><span style={{width:`${((current+1)/examQuestions.length)*100}%`}} /></div>
          <div className="qmeta">Question {current+1} of {examQuestions.length}</div>
          <h2>{q.q}</h2>
          <div className="options">
            {q.options.map((op,i)=><button key={i} className={answers[q.id]===i ? "option selected" : "option"} onClick={()=>setAnswers({...answers,[q.id]:i})}><b>{String.fromCharCode(65+i)}.</b> {op}</button>)}
          </div>
          <div className="nav">
            <button disabled={current===0} onClick={()=>setCurrent(current-1)}>Previous</button>
            {current < examQuestions.length-1
              ? <button className="primary" onClick={()=>setCurrent(current+1)}>Next</button>
              : <button className="danger" onClick={finishExam}>Submit Exam</button>}
          </div>
        </section>
      </main>
    );
  }

  if (screen === "result") {
    return (
      <main className="app center">
        <section className="result-card">
          <div className="logo">U</div>
          <h1>Exam Completed 🎉</h1>
          <p>{student.name} • {selected.code}</p>
          <div className="score">{result.percentage}%</div>
          <h2>{result.correct} / {result.total} Correct</h2>
          <p className={result.percentage >= 50 ? "pass" : "fail"}>{result.percentage >= 50 ? "PASS" : "FAIL"}</p>
          <button className="primary" onClick={()=>setScreen("home")}>Back to Courses</button>
        </section>
      </main>
    );
  }

  if (screen === "admin") {
    return (
      <main className="app">
        <header className="topbar"><b>UNILESA CBT — ADMIN</b><button onClick={()=>setScreen("home")}>Student Portal</button></header>
        {!adminUnlocked ? (
          <section className="panel narrow">
            <h1>Admin Login</h1>
            <p className="muted">Demo password: <b>unilesa2026</b>. Change this before real deployment.</p>
            <input type="password" placeholder="Admin password" value={adminPassword} onChange={e=>setAdminPassword(e.target.value)} />
            <button className="primary full" onClick={()=>adminPassword==="unilesa2026" ? setAdminUnlocked(true) : alert("Wrong password")}>Login</button>
          </section>
        ) : (
          <section className="admin-grid">
            <div className="panel">
              <h2>Add Course</h2>
              <form onSubmit={addCourse} className="form">
                <input placeholder="Course code e.g. BUA 101" value={newCourse.code} onChange={e=>setNewCourse({...newCourse,code:e.target.value})}/>
                <input placeholder="Course title" value={newCourse.title} onChange={e=>setNewCourse({...newCourse,title:e.target.value})}/>
                <input placeholder="Department" value={newCourse.department} onChange={e=>setNewCourse({...newCourse,department:e.target.value})}/>
                <select value={newCourse.level} onChange={e=>setNewCourse({...newCourse,level:e.target.value})}><option>100</option><option>200</option><option>300</option><option>400</option></select>
                <input type="number" min="1" placeholder="Minutes" value={newCourse.duration} onChange={e=>setNewCourse({...newCourse,duration:Number(e.target.value)})}/>
                <button className="primary">Add Course</button>
              </form>
            </div>
            <div className="panel">
              <h2>Add Question</h2>
              <select value={selected?.code || ""} onChange={e=>setSelected(courses.find(c=>c.code===e.target.value)||null)}>
                <option value="">Select course</option>{courses.map(c=><option key={c.code}>{c.code}</option>)}
              </select>
              <form onSubmit={addQuestion} className="form">
                <textarea placeholder="Question" value={newQuestion.q} onChange={e=>setNewQuestion({...newQuestion,q:e.target.value})}/>
                {["a","b","c","d"].map(k=><input key={k} placeholder={`Option ${k.toUpperCase()}`} value={newQuestion[k]} onChange={e=>setNewQuestion({...newQuestion,[k]:e.target.value})}/>)}
                <select value={newQuestion.answer} onChange={e=>setNewQuestion({...newQuestion,answer:e.target.value})}>
                  <option value="0">Correct: A</option><option value="1">Correct: B</option><option value="2">Correct: C</option><option value="3">Correct: D</option>
                </select>
                <button className="primary">Add Question</button>
              </form>
            </div>
            <div className="panel wide">
              <h2>Question Bank</h2>
              {courses.map(c=><div className="course-row" key={c.code}><span><b>{c.code}</b> — {c.title}</span><span>{c.questions.length} questions</span></div>)}
              <button onClick={exportData}>Export Question Bank JSON</button>
            </div>
          </section>
        )}
      </main>
    );
  }

  return (
    <main className="app">
      <header className="hero">
        <div className="brand"><div className="logo">U</div><div><h1>UNILESA CBT PRACTICE</h1><p>University of Ilesa • Student Examination Practice</p></div></div>
        <button className="admin-link" onClick={()=>setScreen("admin")}>Admin</button>
      </header>
      <section className="panel student-panel">
        <h2>Student Information</h2>
        <div className="form grid2">
          <input placeholder="Full name" value={student.name} onChange={e=>setStudent({...student,name:e.target.value})}/>
          <input placeholder="Matric / Registration number" value={student.matric} onChange={e=>setStudent({...student,matric:e.target.value})}/>
          <select value={student.level} onChange={e=>setStudent({...student,level:e.target.value})}><option>100</option><option>200</option><option>300</option><option>400</option></select>
          <input placeholder="Department" value={student.department} onChange={e=>setStudent({...student,department:e.target.value})}/>
        </div>
      </section>
      <section>
        <div className="section-title"><h2>Available Courses</h2><span>{filteredCourses.length} courses</span></div>
        <div className="course-grid">
          {filteredCourses.map(c=><article className="course-card" key={c.code}>
            <span className="badge">{c.code}</span><h3>{c.title}</h3><p>{c.department} • {c.level} Level</p><div className="stats">📝 {c.questions.length} questions &nbsp; ⏱ {c.duration} mins</div>
            <button className="primary full" onClick={()=>startExam(c)}>Start Practice</button>
          </article>)}
        </div>
        {!filteredCourses.length && <div className="empty">No courses found for this department/level yet. Admin can add them.</div>}
      </section>
      <footer>UNILESA CBT Practice • For educational practice</footer>
    </main>
  );
}