# UNILESA CBT Practice System

A working Next.js starter for a University of Ilesa CBT practice platform.

## Included
- Student name, matric number, level and department
- Course selection
- Randomized questions
- A-D multiple choice answers
- Countdown timer
- Automatic scoring
- Pass/fail result
- Admin course creation
- Admin question creation
- JSON question-bank export
- Mobile responsive design

## Run locally

```bash
npm install
npm run dev
```

Open http://localhost:3000

## Admin
Demo password: `unilesa2026`

IMPORTANT: This demo stores data in browser localStorage. It is NOT suitable for a real public exam system until the admin login and database are moved to a server/database.

## Production upgrade
For a real multi-student system, connect the app to Supabase/PostgreSQL and add:
- real admin authentication
- server-side question storage
- server-side exam attempts/results
- student accounts
- anti-cheating controls
- result history
- CSV/Excel question import
- proper role permissions
