import CBTApp from "../components/CBTApp";

export default function Home() {
  return <CBTApp />;
}