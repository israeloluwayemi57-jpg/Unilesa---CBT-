import "./globals.css";

export const metadata = {
  title: "UNILESA CBT Practice",
  description: "University of Ilesa CBT practice platform"
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}